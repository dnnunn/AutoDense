from __future__ import annotations
import os, json, re
from pathlib import Path
from typing import Any, Dict, Optional

def _extract_json(s: str) -> Dict[str, Any]:
    m = re.search(r"\{[\s\S]*\}\s*$", s.strip())
    if not m:
        raise ValueError("Model did not return a JSON object")
    return json.loads(m.group(0))

def openai_call(system_path: str, payload: Dict[str, Any], model: Optional[str]=None) -> Dict[str, Any]:
    from openai import OpenAI
    client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
    sys_prompt = Path(system_path).read_text(encoding="utf-8")
    model = model or os.environ.get("OPENAI_MODEL","gpt-4o-mini")
    resp = client.chat.completions.create(
        model=model,
        messages=[{"role":"system","content":sys_prompt},
                  {"role":"user","content":json.dumps(payload)}],
        temperature=0.1
    )
    return _extract_json(resp.choices[0].message.content)

def gemini_call(system_path: str, payload: Dict[str, Any], model: Optional[str]=None) -> Dict[str, Any]:
    import google.generativeai as genai
    genai.configure(api_key=os.environ["GEMINI_API_KEY"])
    sys_prompt = Path(system_path).read_text(encoding="utf-8")
    model = model or os.environ.get("GEMINI_MODEL","gemini-1.5-pro-latest")
    g = genai.GenerativeModel(model, system_instruction=sys_prompt)
    resp = g.generate_content(json.dumps(payload), generation_config={"temperature":0.1})
    return _extract_json(resp.text)

def grok_call(system_path: str, payload: Dict[str, Any], model: Optional[str]=None) -> Dict[str, Any]:
    import requests
    url = "https://api.x.ai/v1/chat/completions"
    headers = {"Authorization": f"Bearer {os.environ['XAI_API_KEY']}","Content-Type":"application/json"}
    sys_prompt = Path(system_path).read_text(encoding="utf-8")
    model = model or os.environ.get("XAI_MODEL","grok-2-latest")
    data = {"model": model,
            "messages":[{"role":"system","content":sys_prompt},
                        {"role":"user","content":json.dumps(payload)}],
            "temperature":0.1}
    r = requests.post(url, headers=headers, json=data, timeout=60)
    r.raise_for_status()
    return _extract_json(r.json()["choices"][0]["message"]["content"])

def propose_patch_orchestrator(provider: str, run_report: dict, spec: dict, attempts: list) -> dict:
    payload = {"run_report": run_report, "spec": spec, "attempts": attempts[-3:]}
    if provider == "openai": return openai_call("prompts/orchestrator.system.md", payload)
    if provider == "gemini": return gemini_call("prompts/orchestrator.system.md", payload)
    if provider == "grok":   return grok_call("prompts/orchestrator.system.md", payload)
    raise ValueError("Unknown provider")

def review_patch_helper(provider: str, run_report: dict, spec: dict, proposal: dict) -> dict:
    payload = {"run_report": run_report, "spec": spec, "proposal": proposal}
    if provider == "openai": return openai_call("prompts/helper.system.md", payload)
    if provider == "gemini": return gemini_call("prompts/helper.system.md", payload)
    if provider == "grok":   return grok_call("prompts/helper.system.md", payload)
    raise ValueError("Unknown provider")
